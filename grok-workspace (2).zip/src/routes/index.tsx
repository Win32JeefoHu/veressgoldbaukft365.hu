import { createFileRoute } from "@tanstack/react-router";
import { About } from "@/components/about";
import { Hero } from "@/components/hero";
import { Process } from "@/components/process";
import { QuoteForm } from "@/components/quote-form";
import { Services } from "@/components/services";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <div className="min-h-dvh bg-bg text-fg">
      <SiteHeader />
      <main>
        <Hero />
        <Services />
        <Process />
        <About />
        <QuoteForm />
      </main>
      <SiteFooter />
    </div>
  );
}
