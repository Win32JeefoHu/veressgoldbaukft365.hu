export const COMPANY = {
  legalName: "Veress Gold Bau 369 Kft.",
  shortName: "Veress Gold Bau",
  mark: "VERESS",
  markSub: "Gold Bau 369",
  tagline: "Pontos határidők. Megbízható csapat.",
  email: "veress.gold.bau@gmail.com",
  phoneDisplay: "+36 70 361 4340",
  phoneTel: "+36703614340",
  city: "Budapest",
  area: "Budapest teljes területe és Pest megye",
  facebook: "https://www.facebook.com/share/1D1nqgrnX9/",
  whatsapp:
    "https://wa.me/36703614340?text=" +
    encodeURIComponent(
      "Helló! Ajánlatot szeretnék kérni a Veress Gold Bau 369 Kft.-től.",
    ),
  sinceYear: "2021",
  sinceLabel: "2021. május",
} as const;

export const SERVICES = [
  {
    id: "bontas",
    title: "Bontási munkák",
    lead: "Tiszta, ütemezett bontás — lakóépület, toldalék, belső szerkezet.",
    body: "Lakossági és céges megrendelésre vállaljuk a bontást úgy, hogy a következő munkafázisnak rendezett, biztonságos terep maradjon.",
  },
  {
    id: "elokeszites",
    title: "Felújítási előkészítés",
    lead: "Szerkezetfeltárás, tehermentesítés, munkaasztal a felújítás előtt.",
    body: "A szép végeredmény a láthatatlan előkészítésen dől el. Mi ezt a részt is komolyan vesszük.",
  },
  {
    id: "general",
    title: "Generálkivitelezés",
    lead: "Egy felelős, egy ütemterv, egy átadás.",
    body: "A teljes kivitelezést egy kézben tartjuk: egyeztetés, szervezés, határidő. Önnek nem kell öt alvállalkozót terelgetni.",
  },
  {
    id: "haz",
    title: "Családi házak",
    lead: "Új építés és bővítés — kulcsrakészen vagy szerkezetkészen.",
    body: "Családi házak Budapesten és Pest megyében, a tervtől az átadásig.",
  },
  {
    id: "nyaralo",
    title: "Nyaralók",
    lead: "Hétvégi ház, üdülő, könnyű- és hagyományos szerkezet.",
    body: "Nyaralóépítés és felújítás, a telek adottságaihoz igazítva.",
  },
  {
    id: "lakas",
    title: "Lakásfelújítás",
    lead: "Komplett belső felújítás, ütemezetten, lakott környezetben is.",
    body: "Fürdő, konyha, teljes lakás — tiszta munkavégzés, egyeztetett határidővel.",
  },
] as const;

export const PROCESS = [
  {
    n: "01",
    title: "Egyeztetés",
    body: "Röviden elmondja, mit szeretne. Facebookon, telefonon vagy az űrlapon — mindegy, gyorsan válaszolunk.",
  },
  {
    n: "02",
    title: "Helyszíni felmérés",
    body: "Kimegyünk, megnézzük a terepet, a szerkezetet, a hozzáférést. Ebből lesz a valós ajánlat — nem tippelés.",
  },
  {
    n: "03",
    title: "Ajánlat",
    body: "Írásos, átlátható ajánlat: munkanemek, ütem, díj. Nincs rejtett sor a végén.",
  },
  {
    n: "04",
    title: "Kivitelezés",
    body: "A megbeszélt napon kezdünk, a megbeszélt napon adunk át. Ez nálunk nem szlogen.",
  },
] as const;
