import { useEffect, useState } from "react";
import { Menu, Phone, X } from "lucide-react";
import { BrandMark } from "@/components/brand-mark";
import { COMPANY } from "@/lib/company";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "#szolgaltatasok", label: "Szolgáltatások" },
  { href: "#menet", label: "Menet" },
  { href: "#rolunk", label: "Rólunk" },
  { href: "#ajanlat", label: "Ajánlatkérés" },
] as const;

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="pointer-events-none fixed inset-x-0 top-0 z-50 px-3 pt-3 md:px-6 md:pt-5">
      <div
        className={cn(
          "pointer-events-auto mx-auto flex max-w-6xl items-center gap-3 rounded-full px-2 py-1.5 pl-2 pr-2 transition-[background,box-shadow,backdrop-filter] duration-250 ease-[cubic-bezier(0.22,1,0.36,1)] md:pr-1.5",
          scrolled || open
            ? "bg-bg-elevated/80 shadow-nav backdrop-blur-xl"
            : "bg-bg/25 backdrop-blur-md",
        )}
      >
        <a
          href="#top"
          className="flex min-h-11 items-center gap-2.5 rounded-full py-0.5 pr-3 pl-0.5"
        >
          <BrandMark size={40} />
          <span className="flex flex-col leading-none">
            <span className="font-display text-[17px] font-semibold tracking-tight text-fg">
              {COMPANY.shortName}
            </span>
            <span className="mt-0.5 text-[10px] tracking-[0.18em] text-gold uppercase">
              369 Kft.
            </span>
          </span>
        </a>

        <nav className="ml-auto hidden items-center gap-1 lg:flex">
          {LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="rounded-full px-3.5 py-2 text-sm text-muted transition-colors duration-150 hover:text-fg"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <a
          href={`tel:${COMPANY.phoneTel}`}
          className="ml-auto hidden min-h-11 items-center gap-2 rounded-full px-3 text-sm text-fg/90 transition-colors duration-150 hover:text-gold md:ml-2 md:flex lg:ml-3"
        >
          <Phone className="size-3.5" strokeWidth={1.75} />
          <span className="tabular-nums">{COMPANY.phoneDisplay}</span>
        </a>

        <a
          href="#ajanlat"
          className="hidden min-h-11 items-center rounded-full bg-gold px-4 text-sm font-medium text-bg transition-transform duration-150 ease-out hover:bg-gold-bright active:scale-[0.96] md:inline-flex"
        >
          Ajánlatkérés
        </a>

        <button
          type="button"
          className="ml-auto flex size-11 items-center justify-center rounded-full text-fg md:ml-0 lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          aria-label={open ? "Menü bezárása" : "Menü megnyitása"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>

      {open ? (
        <div
          id="mobile-nav"
          className="pointer-events-auto mx-auto mt-2 max-w-6xl overflow-hidden rounded-3xl bg-bg-elevated/95 p-3 shadow-nav backdrop-blur-xl lg:hidden"
        >
          <nav className="flex flex-col">
            {LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="flex min-h-12 items-center rounded-2xl px-4 text-base text-fg"
                onClick={() => setOpen(false)}
              >
                {link.label}
              </a>
            ))}
            <a
              href={`tel:${COMPANY.phoneTel}`}
              className="mt-1 flex min-h-12 items-center gap-2 rounded-2xl px-4 text-muted"
            >
              <Phone className="size-4" />
              {COMPANY.phoneDisplay}
            </a>
            <a
              href="#ajanlat"
              onClick={() => setOpen(false)}
              className="mt-2 flex min-h-12 items-center justify-center rounded-2xl bg-gold text-sm font-medium text-bg"
            >
              Ajánlatkérés
            </a>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
