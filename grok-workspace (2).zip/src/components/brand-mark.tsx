import { cn } from "@/lib/utils";

export function BrandMark({
  className,
  size = 44,
}: {
  className?: string;
  size?: number;
}) {
  return (
    <img
      src="/logo.png"
      alt="Veress Gold Bau 369"
      width={size}
      height={size}
      className={cn(
        "rounded-full object-cover outline -outline-offset-1 outline-gold/30",
        className,
      )}
      style={{ width: size, height: size }}
    />
  );
}

export function RoofMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 88 44"
      fill="none"
      aria-hidden="true"
      className={cn("text-gold", className)}
    >
      <path
        d="M10 30 L32 12 L44 24 L60 10 L78 30"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16 20 V11 H20 V16"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <g fill="currentColor">
        <rect x="40.2" y="26" width="3.2" height="3.2" rx="0.3" />
        <rect x="44.6" y="26" width="3.2" height="3.2" rx="0.3" />
        <rect x="40.2" y="30.4" width="3.2" height="3.2" rx="0.3" />
        <rect x="44.6" y="30.4" width="3.2" height="3.2" rx="0.3" />
      </g>
    </svg>
  );
}
