import { useMemo, useState, type FormEvent, type ReactNode } from "react";
import { Mail, Send, X } from "lucide-react";
import { FacebookIcon, WhatsAppIcon } from "@/components/icons";
import { COMPANY, SERVICES } from "@/lib/company";

type FormState = {
  name: string;
  phone: string;
  email: string;
  service: string;
  location: string;
  message: string;
};

const EMPTY: FormState = {
  name: "",
  phone: "",
  email: "",
  service: "",
  location: "",
  message: "",
};

function buildBody(data: FormState) {
  return [
    "VERESS GOLD BAU 369 KFT",
    COMPANY.tagline,
    "",
    "—— AJÁNLATKÉRÉS ——",
    `Név: ${data.name}`,
    `Telefon: ${data.phone}`,
    data.email ? `E-mail: ${data.email}` : null,
    `Munka jellege: ${data.service}`,
    data.location ? `Helyszín: ${data.location}` : null,
    "",
    "Üzenet:",
    data.message || "—",
    "",
    "——",
    COMPANY.email,
    COMPANY.phoneDisplay,
    COMPANY.area,
  ]
    .filter((line) => line !== null)
    .join("\n");
}

export function QuoteForm() {
  const [data, setData] = useState<FormState>(EMPTY);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const subject = useMemo(
    () =>
      `Ajánlatkérés — ${data.name || "megrendelő"} — ${data.service || "Veress Gold Bau 369"}`,
    [data.name, data.service],
  );

  function onChange<K extends keyof FormState>(key: K, value: FormState[K]) {
    setData((prev) => ({ ...prev, [key]: value }));
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!data.name.trim() || !data.phone.trim() || !data.service) {
      setError("Kérjük, adja meg a nevét, telefonszámát és a munka jellegét.");
      return;
    }
    setError(null);
    setOpen(true);
  }

  function sendGmail() {
    const url = new URL("https://mail.google.com/mail/");
    url.searchParams.set("view", "cm");
    url.searchParams.set("fs", "1");
    url.searchParams.set("to", COMPANY.email);
    url.searchParams.set("su", subject);
    url.searchParams.set("body", buildBody(data));
    window.open(url.toString(), "_blank", "noopener,noreferrer");
  }

  function sendMailto() {
    const href = `mailto:${COMPANY.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(buildBody(data))}`;
    window.location.href = href;
  }

  return (
    <section id="ajanlat" className="bg-bg-elevated px-5 py-24 md:px-8 md:py-32">
      <div className="mx-auto grid max-w-6xl gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        <div>
          <p className="text-xs tracking-[0.22em] text-gold uppercase">Ajánlatkérés</p>
          <h2 className="font-display mt-4 text-4xl leading-[1.05] font-medium tracking-[-0.03em] text-fg md:text-5xl">
            Írja meg, mit szeretne.
            <span className="mt-1 block italic text-gold">Mi visszaírunk.</span>
          </h2>
          <p className="mt-6 text-sm leading-relaxed text-muted">
            Töltse ki az űrlapot — a küldés előtt megmutatjuk a levél sablonját a cég
            logójával, majd Gmailen keresztül továbbítjuk a{" "}
            <span className="text-fg">{COMPANY.email}</span> címre. Adatbázis nincs:
            a levél az Ön Gmail-fiókjából megy ki.
          </p>

          <div className="mt-10 flex flex-col gap-3">
            <a
              href={COMPANY.facebook}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-12 items-center gap-3 rounded-2xl bg-surface px-4 text-sm text-fg shadow-card transition-[box-shadow] duration-150 hover:shadow-card-hover"
            >
              <FacebookIcon className="size-4 text-gold" />
              Kérjen ajánlatot Facebook-üzenetben
            </a>
            <a
              href={COMPANY.whatsapp}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-12 items-center gap-3 rounded-2xl bg-surface px-4 text-sm text-fg shadow-card transition-[box-shadow] duration-150 hover:shadow-card-hover"
            >
              <WhatsAppIcon className="size-4 text-gold" />
              WhatsApp: {COMPANY.phoneDisplay}
            </a>
            <a
              href={`mailto:${COMPANY.email}`}
              className="inline-flex min-h-12 items-center gap-3 rounded-2xl bg-surface px-4 text-sm text-fg shadow-card transition-[box-shadow] duration-150 hover:shadow-card-hover"
            >
              <Mail className="size-4 text-gold" strokeWidth={1.6} />
              {COMPANY.email}
            </a>
          </div>
        </div>

        <form
          onSubmit={onSubmit}
          className="rounded-[1.75rem] bg-surface p-5 shadow-card md:p-8"
          noValidate
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Név" htmlFor="name">
              <input
                id="name"
                className="letter-input"
                autoComplete="name"
                value={data.name}
                onChange={(e) => onChange("name", e.target.value)}
                placeholder="Teljes név"
              />
            </Field>
            <Field label="Telefon" htmlFor="phone">
              <input
                id="phone"
                className="letter-input"
                autoComplete="tel"
                inputMode="tel"
                value={data.phone}
                onChange={(e) => onChange("phone", e.target.value)}
                placeholder="+36 …"
              />
            </Field>
            <Field label="E-mail" htmlFor="email">
              <input
                id="email"
                type="email"
                className="letter-input"
                autoComplete="email"
                value={data.email}
                onChange={(e) => onChange("email", e.target.value)}
                placeholder="opcionális"
              />
            </Field>
            <Field label="Helyszín" htmlFor="location">
              <input
                id="location"
                className="letter-input"
                value={data.location}
                onChange={(e) => onChange("location", e.target.value)}
                placeholder="Budapest, kerület / település"
              />
            </Field>
            <div className="sm:col-span-2">
              <Field label="Munka jellege" htmlFor="service">
                <select
                  id="service"
                  className="letter-input"
                  value={data.service}
                  onChange={(e) => onChange("service", e.target.value)}
                >
                  <option value="">Válasszon…</option>
                  {SERVICES.map((s) => (
                    <option key={s.id} value={s.title}>
                      {s.title}
                    </option>
                  ))}
                  <option value="Egyéb">Egyéb</option>
                </select>
              </Field>
            </div>
            <div className="sm:col-span-2">
              <Field label="Rövid leírás" htmlFor="message">
                <textarea
                  id="message"
                  className="letter-input"
                  value={data.message}
                  onChange={(e) => onChange("message", e.target.value)}
                  placeholder="Milyen munkáról van szó, mikorra tervezi, van-e terv?"
                />
              </Field>
            </div>
          </div>

          {error ? (
            <p className="mt-4 text-sm text-gold-bright" role="alert">
              {error}
            </p>
          ) : null}

          <button
            type="submit"
            className="mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-gold px-6 text-sm font-medium text-bg transition-transform duration-150 ease-out hover:bg-gold-bright active:scale-[0.96]"
          >
            Levél sablon megtekintése
            <Send className="size-4" strokeWidth={1.7} />
          </button>
          <p className="mt-3 text-center text-xs leading-relaxed text-subtle">
            A küldés a Gmail ablakában történik. Semmit nem tárolunk a weblapon.
          </p>
        </form>
      </div>

      {open ? (
        <div
          className="fixed inset-0 z-[60] flex items-end justify-center bg-bg/70 p-3 backdrop-blur-sm sm:items-center"
          role="dialog"
          aria-modal="true"
          aria-labelledby="letter-title"
          onClick={(e) => {
            if (e.target === e.currentTarget) setOpen(false);
          }}
        >
          <div className="max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-[1.75rem] bg-paper p-6 text-ink shadow-paper md:p-8">
            <div className="flex items-start justify-between">
              <h3 id="letter-title" className="sr-only">
                Levél sablon
              </h3>
              <button
                type="button"
                className="ml-auto flex size-11 items-center justify-center rounded-full text-ink-muted hover:text-ink"
                onClick={() => setOpen(false)}
                aria-label="Bezárás"
              >
                <X className="size-5" />
              </button>
            </div>

            <div className="flex flex-col items-center text-center">
              <img
                src="/logo.png"
                alt="Veress Gold Bau 369 logó"
                width={96}
                height={96}
                className="size-24 rounded-full outline outline-1 -outline-offset-1 outline-ink/15"
              />
              <p className="font-display mt-4 text-2xl font-semibold tracking-tight text-ink">
                {COMPANY.legalName}
              </p>
              <p className="mt-1 text-xs tracking-[0.18em] text-gold-dim uppercase">
                {COMPANY.tagline}
              </p>
              <div className="mt-5 h-px w-16 bg-gold/60" />
            </div>

            <dl className="mt-8 space-y-3 text-left text-sm">
              <Row k="Név" v={data.name} />
              <Row k="Telefon" v={data.phone} />
              {data.email ? <Row k="E-mail" v={data.email} /> : null}
              <Row k="Munka" v={data.service} />
              {data.location ? <Row k="Helyszín" v={data.location} /> : null}
            </dl>

            {data.message ? (
              <p className="mt-6 border-t border-ink/10 pt-5 text-left text-sm leading-relaxed text-ink-muted whitespace-pre-wrap">
                {data.message}
              </p>
            ) : null}

            <p className="mt-8 text-center text-[11px] tracking-wide text-ink-muted">
              {COMPANY.email} · {COMPANY.phoneDisplay}
            </p>

            <div className="mt-6 grid gap-2 sm:grid-cols-2">
              <button
                type="button"
                onClick={sendGmail}
                className="inline-flex min-h-12 items-center justify-center rounded-full bg-ink px-4 text-sm font-medium text-paper transition-transform duration-150 active:scale-[0.96]"
              >
                Küldés Gmailben
              </button>
              <button
                type="button"
                onClick={sendMailto}
                className="inline-flex min-h-12 items-center justify-center rounded-full px-4 text-sm font-medium text-ink shadow-[inset_0_0_0_1px_rgba(26,23,20,0.18)] transition-transform duration-150 active:scale-[0.96]"
              >
                Megnyitás levelezőben
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}

function Field({
  label,
  htmlFor,
  children,
}: {
  label: string;
  htmlFor: string;
  children: ReactNode;
}) {
  return (
    <label htmlFor={htmlFor} className="block">
      <span className="mb-1.5 block text-xs tracking-[0.14em] text-muted uppercase">
        {label}
      </span>
      {children}
    </label>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="grid grid-cols-[7rem_1fr] gap-3">
      <dt className="text-ink-muted">{k}</dt>
      <dd className="font-medium text-ink">{v}</dd>
    </div>
  );
}
