import { ArrowDownRight, MapPin } from "lucide-react";
import { FacebookIcon } from "@/components/icons";
import { COMPANY } from "@/lib/company";

export function Hero() {
  return (
    <section id="top" className="relative min-h-dvh overflow-hidden">
      <img
        src="/hero.jpg"
        alt="Új, kortárs családi ház alkonyatkor — a Veress Gold Bau 369 kivitelezési minőségének hangulata."
        className="absolute inset-0 size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/20" />
      <div className="absolute inset-0 bg-gradient-to-r from-bg/80 via-bg/25 to-transparent" />

      <div className="relative mx-auto flex min-h-dvh max-w-6xl flex-col justify-end px-5 pb-24 pt-32 md:px-8 md:pb-28">
        <p className="mb-5 flex items-center gap-2 text-xs tracking-[0.22em] text-gold uppercase">
          <MapPin className="size-3.5" strokeWidth={1.75} />
          {COMPANY.area}
        </p>

        <h1 className="font-display max-w-3xl text-[2.65rem] leading-[0.95] font-medium tracking-[-0.03em] text-fg sm:text-6xl md:text-[5.25rem]">
          A határidő nálunk
          <span className="mt-1 block italic text-gold-bright">nem tájékoztató.</span>
        </h1>

        <p className="mt-6 max-w-xl text-base leading-relaxed text-muted md:text-lg">
          Bontás, felújítási előkészítés és generálkivitelezés lakossági és céges
          megrendelőknek. Pontosan, ahogy megbeszéltük.
        </p>

        <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
          <a
            href="#ajanlat"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-gold px-6 text-sm font-medium text-bg transition-transform duration-150 ease-out hover:bg-gold-bright active:scale-[0.96]"
          >
            Ajánlatot kérek
            <ArrowDownRight className="size-4" strokeWidth={1.75} />
          </a>
          <a
            href={COMPANY.facebook}
            target="_blank"
            rel="noreferrer"
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-6 text-sm font-medium text-fg shadow-[inset_0_0_0_1px_rgba(244,239,228,0.16)] transition-colors duration-150 hover:shadow-[inset_0_0_0_1px_rgba(201,164,74,0.5)]"
          >
            <FacebookIcon className="size-4" />
            Facebook-üzenet
          </a>
        </div>

        <dl className="mt-16 grid max-w-2xl grid-cols-3 gap-4 border-t border-fg/10 pt-6">
          <div>
            <dt className="text-[10px] tracking-[0.18em] text-subtle uppercase">Alapítva</dt>
            <dd className="font-display mt-1 text-2xl text-fg md:text-3xl">{COMPANY.sinceYear}</dd>
          </div>
          <div>
            <dt className="text-[10px] tracking-[0.18em] text-subtle uppercase">Terület</dt>
            <dd className="font-display mt-1 text-2xl whitespace-nowrap text-fg md:text-3xl">
              Budapest
            </dd>
          </div>
          <div>
            <dt className="text-[10px] tracking-[0.18em] text-subtle uppercase">Munka</dt>
            <dd className="font-display mt-1 text-2xl text-fg md:text-3xl">Generál</dd>
          </div>
        </dl>
      </div>
    </section>
  );
}
