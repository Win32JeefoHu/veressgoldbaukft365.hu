import { Clock, Hammer, MapPin, Users } from "lucide-react";
import { COMPANY } from "@/lib/company";

const POINTS = [
  {
    icon: Clock,
    title: "Pontos határidők",
    body: "Az építőiparban a határidőt gyakran csak tájékoztatónak hívják. Nálunk a naptár a szerződés része.",
  },
  {
    icon: Users,
    title: "Megbízható csapat",
    body: "Egy felelős a munkáért. Nem tűnik el a kivitelezés közepén, és nem hárít a következő szakemberre.",
  },
  {
    icon: Hammer,
    title: "Bontástól az átadásig",
    body: "Előkészítés, bontás, felújítás, generálkivitelezés — lakossági és céges megrendelésre.",
  },
  {
    icon: MapPin,
    title: "Budapest és Pest megye",
    body: `Munkavállalás ${COMPANY.city} teljes területén és Pest megyében. ${COMPANY.sinceLabel} óta.`,
  },
] as const;

export function About() {
  return (
    <section id="rolunk" className="bg-bg px-5 py-24 md:px-8 md:py-32">
      <div className="mx-auto grid max-w-6xl gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-center">
        <div className="relative overflow-hidden rounded-[2rem]">
          <img
            src="/hero.jpg"
            alt="Kortárs családi ház esti fényben"
            className="aspect-[4/5] w-full object-cover outline outline-1 -outline-offset-1 outline-fg/10 sm:aspect-[5/4] lg:aspect-[4/5]"
          />
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg/90 to-transparent p-6">
            <p className="font-display text-2xl italic text-fg">
              {COMPANY.tagline}
            </p>
          </div>
        </div>

        <div>
          <p className="text-xs tracking-[0.22em] text-gold uppercase">Rólunk</p>
          <h2 className="font-display mt-4 text-4xl leading-[1.05] font-medium tracking-[-0.03em] text-fg md:text-5xl">
            {COMPANY.legalName}
          </h2>
          <p className="mt-6 text-base leading-relaxed text-muted">
            Építőipari vállalkozás Budapesten. Családi házak, nyaralók, lakásfelújítás
            és generálkivitelezés — a bontási munkáktól a felújítási előkészítésig.
            Azt ígérjük, amit tartani is tudunk.
          </p>

          <ul className="mt-10 grid gap-6 sm:grid-cols-2">
            {POINTS.map((point) => (
              <li key={point.title}>
                <point.icon className="size-5 text-gold" strokeWidth={1.5} />
                <h3 className="mt-3 text-sm font-medium text-fg">{point.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted">{point.body}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
