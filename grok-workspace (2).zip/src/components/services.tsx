import { RoofMark } from "@/components/brand-mark";
import { SERVICES } from "@/lib/company";

export function Services() {
  return (
    <section id="szolgaltatasok" className="relative bg-bg px-5 py-24 md:px-8 md:py-32">
      <div className="mx-auto max-w-6xl">
        <p className="text-xs tracking-[0.22em] text-gold uppercase">Szolgáltatások</p>
        <div className="mt-4 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <h2 className="font-display max-w-xl text-4xl leading-[1.05] font-medium tracking-[-0.03em] text-fg md:text-5xl">
            Amit egy kézben tartunk.
          </h2>
          <p className="max-w-sm text-sm leading-relaxed text-muted">
            Lakossági és céges megrendelőknek — bontástól a kulcsátadásig, Budapesten
            és Pest megyében.
          </p>
        </div>

        <ul className="mt-14 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service, i) => (
            <li
              key={service.id}
              className="group rounded-3xl bg-surface p-6 shadow-card transition-[box-shadow,transform] duration-250 ease-[cubic-bezier(0.22,1,0.36,1)] hover:shadow-card-hover"
            >
              <div className="flex items-start justify-between">
                <RoofMark className="h-8 w-16 opacity-80" />
                <span className="font-display text-sm text-gold/70">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>
              <h3 className="font-display mt-8 text-2xl font-medium tracking-tight text-fg">
                {service.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-muted">{service.lead}</p>
              <p className="mt-3 text-sm leading-relaxed text-subtle">{service.body}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
