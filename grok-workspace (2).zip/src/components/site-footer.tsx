import { Mail, MapPin, Phone } from "lucide-react";
import { BrandMark } from "@/components/brand-mark";
import { FacebookIcon, WhatsAppIcon } from "@/components/icons";
import { COMPANY } from "@/lib/company";

export function SiteFooter() {
  return (
    <footer id="kapcsolat" className="border-t border-fg/10 bg-bg px-5 py-16 md:px-8">
      <div className="mx-auto grid max-w-6xl gap-10 md:grid-cols-[1.2fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-3">
            <BrandMark size={48} />
            <div>
              <p className="font-display text-xl font-semibold text-fg">{COMPANY.shortName}</p>
              <p className="text-xs tracking-[0.16em] text-gold uppercase">369 Kft.</p>
            </div>
          </div>
          <p className="mt-5 max-w-sm text-sm leading-relaxed text-muted">
            {COMPANY.tagline} Bontás, felújítás, generálkivitelezés — {COMPANY.area}.
          </p>
        </div>

        <div>
          <p className="text-xs tracking-[0.18em] text-subtle uppercase">Elérhetőség</p>
          <ul className="mt-4 space-y-3 text-sm">
            <li>
              <a
                href={`tel:${COMPANY.phoneTel}`}
                className="inline-flex min-h-11 items-center gap-2 text-fg hover:text-gold"
              >
                <Phone className="size-4 text-gold" strokeWidth={1.6} />
                {COMPANY.phoneDisplay}
              </a>
            </li>
            <li>
              <a
                href={`mailto:${COMPANY.email}`}
                className="inline-flex min-h-11 items-center gap-2 text-fg hover:text-gold"
              >
                <Mail className="size-4 text-gold" strokeWidth={1.6} />
                {COMPANY.email}
              </a>
            </li>
            <li className="flex items-start gap-2 text-muted">
              <MapPin className="mt-0.5 size-4 text-gold" strokeWidth={1.6} />
              {COMPANY.area}
            </li>
          </ul>
        </div>

        <div>
          <p className="text-xs tracking-[0.18em] text-subtle uppercase">Üzenet</p>
          <div className="mt-4 flex flex-col gap-2">
            <a
              href={COMPANY.facebook}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-11 items-center gap-2 text-sm text-fg hover:text-gold"
            >
              <FacebookIcon className="size-4 text-gold" />
              Facebook oldal
            </a>
            <a
              href={COMPANY.whatsapp}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-11 items-center gap-2 text-sm text-fg hover:text-gold"
            >
              <WhatsAppIcon className="size-4 text-gold" />
              WhatsApp
            </a>
          </div>
        </div>
      </div>

      <div className="mx-auto mt-12 flex max-w-6xl flex-col gap-2 border-t border-fg/10 pt-6 text-xs text-subtle sm:flex-row sm:items-center sm:justify-between">
        <p>
          © {new Date().getFullYear()} {COMPANY.legalName}
        </p>
        <p>Generálkivitelezés · Házépítés · Lakásfelújítás · Budapest</p>
      </div>
    </footer>
  );
}
