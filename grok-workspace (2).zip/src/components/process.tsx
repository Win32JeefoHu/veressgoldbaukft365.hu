import { PROCESS } from "@/lib/company";

export function Process() {
  return (
    <section id="menet" className="bg-bg-elevated px-5 py-24 md:px-8 md:py-32">
      <div className="mx-auto max-w-6xl">
        <p className="text-xs tracking-[0.22em] text-gold uppercase">Menet</p>
        <h2 className="font-display mt-4 max-w-2xl text-4xl leading-[1.05] font-medium tracking-[-0.03em] text-fg md:text-5xl">
          Négy lépés. Semmi labirintus.
        </h2>

        <ol className="mt-14 grid gap-px overflow-hidden rounded-3xl bg-line sm:grid-cols-2 lg:grid-cols-4">
          {PROCESS.map((step) => (
            <li key={step.n} className="bg-bg-elevated p-7">
              <span className="font-display text-3xl text-gold">{step.n}</span>
              <h3 className="mt-6 text-base font-medium text-fg">{step.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted">{step.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
