//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DUQLtKRB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CcS_9D1r.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CcS_9D1r.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BlmdrgjW.js"]
	}
} });
//#endregion
export { tsrStartManifest };
