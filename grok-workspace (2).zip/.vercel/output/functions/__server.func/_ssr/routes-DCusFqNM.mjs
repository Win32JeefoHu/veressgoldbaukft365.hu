import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Phone, c as Mail, d as ArrowDownRight, i as Send, l as Hammer, n as Users, o as Menu, s as MapPin, t as X, u as Clock } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DCusFqNM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var COMPANY = {
	legalName: "Veress Gold Bau 369 Kft.",
	shortName: "Veress Gold Bau",
	mark: "VERESS",
	markSub: "Gold Bau 369",
	tagline: "Pontos határidők. Megbízható csapat.",
	email: "veress.gold.bau@gmail.com",
	phoneDisplay: "+36 70 361 4340",
	phoneTel: "+36703614340",
	city: "Budapest",
	area: "Budapest teljes területe és Pest megye",
	facebook: "https://www.facebook.com/share/1D1nqgrnX9/",
	whatsapp: "https://wa.me/36703614340?text=" + encodeURIComponent("Helló! Ajánlatot szeretnék kérni a Veress Gold Bau 369 Kft.-től."),
	sinceYear: "2021",
	sinceLabel: "2021. május"
};
var SERVICES = [
	{
		id: "bontas",
		title: "Bontási munkák",
		lead: "Tiszta, ütemezett bontás — lakóépület, toldalék, belső szerkezet.",
		body: "Lakossági és céges megrendelésre vállaljuk a bontást úgy, hogy a következő munkafázisnak rendezett, biztonságos terep maradjon."
	},
	{
		id: "elokeszites",
		title: "Felújítási előkészítés",
		lead: "Szerkezetfeltárás, tehermentesítés, munkaasztal a felújítás előtt.",
		body: "A szép végeredmény a láthatatlan előkészítésen dől el. Mi ezt a részt is komolyan vesszük."
	},
	{
		id: "general",
		title: "Generálkivitelezés",
		lead: "Egy felelős, egy ütemterv, egy átadás.",
		body: "A teljes kivitelezést egy kézben tartjuk: egyeztetés, szervezés, határidő. Önnek nem kell öt alvállalkozót terelgetni."
	},
	{
		id: "haz",
		title: "Családi házak",
		lead: "Új építés és bővítés — kulcsrakészen vagy szerkezetkészen.",
		body: "Családi házak Budapesten és Pest megyében, a tervtől az átadásig."
	},
	{
		id: "nyaralo",
		title: "Nyaralók",
		lead: "Hétvégi ház, üdülő, könnyű- és hagyományos szerkezet.",
		body: "Nyaralóépítés és felújítás, a telek adottságaihoz igazítva."
	},
	{
		id: "lakas",
		title: "Lakásfelújítás",
		lead: "Komplett belső felújítás, ütemezetten, lakott környezetben is.",
		body: "Fürdő, konyha, teljes lakás — tiszta munkavégzés, egyeztetett határidővel."
	}
];
var PROCESS = [
	{
		n: "01",
		title: "Egyeztetés",
		body: "Röviden elmondja, mit szeretne. Facebookon, telefonon vagy az űrlapon — mindegy, gyorsan válaszolunk."
	},
	{
		n: "02",
		title: "Helyszíni felmérés",
		body: "Kimegyünk, megnézzük a terepet, a szerkezetet, a hozzáférést. Ebből lesz a valós ajánlat — nem tippelés."
	},
	{
		n: "03",
		title: "Ajánlat",
		body: "Írásos, átlátható ajánlat: munkanemek, ütem, díj. Nincs rejtett sor a végén."
	},
	{
		n: "04",
		title: "Kivitelezés",
		body: "A megbeszélt napon kezdünk, a megbeszélt napon adunk át. Ez nálunk nem szlogen."
	}
];
var POINTS = [
	{
		icon: Clock,
		title: "Pontos határidők",
		body: "Az építőiparban a határidőt gyakran csak tájékoztatónak hívják. Nálunk a naptár a szerződés része."
	},
	{
		icon: Users,
		title: "Megbízható csapat",
		body: "Egy felelős a munkáért. Nem tűnik el a kivitelezés közepén, és nem hárít a következő szakemberre."
	},
	{
		icon: Hammer,
		title: "Bontástól az átadásig",
		body: "Előkészítés, bontás, felújítás, generálkivitelezés — lakossági és céges megrendelésre."
	},
	{
		icon: MapPin,
		title: "Budapest és Pest megye",
		body: `Munkavállalás ${COMPANY.city} teljes területén és Pest megyében. ${COMPANY.sinceLabel} óta.`
	}
];
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "rolunk",
		className: "bg-bg px-5 py-24 md:px-8 md:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-[2rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/hero.jpg",
					alt: "Kortárs családi ház esti fényben",
					className: "aspect-[4/5] w-full object-cover outline outline-1 -outline-offset-1 outline-fg/10 sm:aspect-[5/4] lg:aspect-[4/5]"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg/90 to-transparent p-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl italic text-fg",
						children: COMPANY.tagline
					})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.22em] text-gold uppercase",
					children: "Rólunk"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mt-4 text-4xl leading-[1.05] font-medium tracking-[-0.03em] text-fg md:text-5xl",
					children: COMPANY.legalName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-base leading-relaxed text-muted",
					children: "Építőipari vállalkozás Budapesten. Családi házak, nyaralók, lakásfelújítás és generálkivitelezés — a bontási munkáktól a felújítási előkészítésig. Azt ígérjük, amit tartani is tudunk."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-10 grid gap-6 sm:grid-cols-2",
					children: POINTS.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(point.icon, {
							className: "size-5 text-gold",
							strokeWidth: 1.5
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 text-sm font-medium text-fg",
							children: point.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-sm leading-relaxed text-muted",
							children: point.body
						})
					] }, point.title))
				})
			] })]
		})
	});
}
function FacebookIcon({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		className,
		fill: "currentColor",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M14.5 8.5V6.7c0-.7.5-1.2 1.2-1.2h1.3V3h-2.3C12.4 3 11 4.5 11 6.8v1.7H9v2.7h2V21h3.5v-9.8h2.3l.4-2.7h-2.7Z" })
	});
}
function WhatsAppIcon({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		"aria-hidden": "true",
		className,
		fill: "currentColor",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12.04 3C7.35 3 3.54 6.74 3.54 11.35c0 1.83.53 3.54 1.45 5L3 21l4.78-1.9a8.5 8.5 0 0 0 4.26 1.14h.04c4.69 0 8.5-3.74 8.5-8.35C20.58 6.74 16.73 3 12.04 3Zm4.84 11.86c-.2.56-1.16 1.07-1.6 1.14-.41.06-.9.09-1.45-.09-.33-.11-.76-.25-1.31-.49-2.31-1-3.82-3.32-3.94-3.47-.12-.16-.97-1.29-.97-2.46 0-1.17.61-1.74.83-1.98.2-.22.45-.28.6-.28h.43c.14 0 .33-.05.51.39.2.48.67 1.64.73 1.76.06.12.1.25.02.41-.08.16-.12.25-.24.39-.12.14-.25.31-.36.42-.12.12-.24.24-.1.47.14.22.62 1.02 1.33 1.65.91.81 1.68 1.06 1.91 1.18.24.12.37.1.51-.06.14-.16.59-.69.75-.92.16-.24.32-.2.54-.12.22.08 1.39.66 1.63.78.24.12.4.18.46.28.06.1.06.56-.14 1.12Z" })
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "top",
		className: "relative min-h-dvh overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/hero.jpg",
				alt: "Új, kortárs családi ház alkonyatkor — a Veress Gold Bau 369 kivitelezési minőségének hangulata.",
				className: "absolute inset-0 size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-bg/80 via-bg/25 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex min-h-dvh max-w-6xl flex-col justify-end px-5 pb-24 pt-32 md:px-8 md:pb-28",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mb-5 flex items-center gap-2 text-xs tracking-[0.22em] text-gold uppercase",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
							className: "size-3.5",
							strokeWidth: 1.75
						}), COMPANY.area]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "font-display max-w-3xl text-[2.65rem] leading-[0.95] font-medium tracking-[-0.03em] text-fg sm:text-6xl md:text-[5.25rem]",
						children: ["A határidő nálunk", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block italic text-gold-bright",
							children: "nem tájékoztató."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 max-w-xl text-base leading-relaxed text-muted md:text-lg",
						children: "Bontás, felújítási előkészítés és generálkivitelezés lakossági és céges megrendelőknek. Pontosan, ahogy megbeszéltük."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-9 flex flex-col gap-3 sm:flex-row sm:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#ajanlat",
							className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-gold px-6 text-sm font-medium text-bg transition-transform duration-150 ease-out hover:bg-gold-bright active:scale-[0.96]",
							children: ["Ajánlatot kérek", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownRight, {
								className: "size-4",
								strokeWidth: 1.75
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: COMPANY.facebook,
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-full px-6 text-sm font-medium text-fg shadow-[inset_0_0_0_1px_rgba(244,239,228,0.16)] transition-colors duration-150 hover:shadow-[inset_0_0_0_1px_rgba(201,164,74,0.5)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FacebookIcon, { className: "size-4" }), "Facebook-üzenet"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-16 grid max-w-2xl grid-cols-3 gap-4 border-t border-fg/10 pt-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[10px] tracking-[0.18em] text-subtle uppercase",
								children: "Alapítva"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display mt-1 text-2xl text-fg md:text-3xl",
								children: COMPANY.sinceYear
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[10px] tracking-[0.18em] text-subtle uppercase",
								children: "Terület"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display mt-1 text-2xl whitespace-nowrap text-fg md:text-3xl",
								children: "Budapest"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[10px] tracking-[0.18em] text-subtle uppercase",
								children: "Munka"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-display mt-1 text-2xl text-fg md:text-3xl",
								children: "Generál"
							})] })
						]
					})
				]
			})
		]
	});
}
function Process() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "menet",
		className: "bg-bg-elevated px-5 py-24 md:px-8 md:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.22em] text-gold uppercase",
					children: "Menet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mt-4 max-w-2xl text-4xl leading-[1.05] font-medium tracking-[-0.03em] text-fg md:text-5xl",
					children: "Négy lépés. Semmi labirintus."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-14 grid gap-px overflow-hidden rounded-3xl bg-line sm:grid-cols-2 lg:grid-cols-4",
					children: PROCESS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "bg-bg-elevated p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-3xl text-gold",
								children: step.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-6 text-base font-medium text-fg",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								children: step.body
							})
						]
					}, step.n))
				})
			]
		})
	});
}
var EMPTY = {
	name: "",
	phone: "",
	email: "",
	service: "",
	location: "",
	message: ""
};
function buildBody(data) {
	return [
		"VERESS GOLD BAU 369 KFT",
		COMPANY.tagline,
		"",
		"—— AJÁNLATKÉRÉS ——",
		`Név: ${data.name}`,
		`Telefon: ${data.phone}`,
		data.email ? `E-mail: ${data.email}` : null,
		`Munka jellege: ${data.service}`,
		data.location ? `Helyszín: ${data.location}` : null,
		"",
		"Üzenet:",
		data.message || "—",
		"",
		"——",
		COMPANY.email,
		COMPANY.phoneDisplay,
		COMPANY.area
	].filter((line) => line !== null).join("\n");
}
function QuoteForm() {
	const [data, setData] = (0, import_react.useState)(EMPTY);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const subject = (0, import_react.useMemo)(() => `Ajánlatkérés — ${data.name || "megrendelő"} — ${data.service || "Veress Gold Bau 369"}`, [data.name, data.service]);
	function onChange(key, value) {
		setData((prev) => ({
			...prev,
			[key]: value
		}));
	}
	function onSubmit(event) {
		event.preventDefault();
		if (!data.name.trim() || !data.phone.trim() || !data.service) {
			setError("Kérjük, adja meg a nevét, telefonszámát és a munka jellegét.");
			return;
		}
		setError(null);
		setOpen(true);
	}
	function sendGmail() {
		const url = new URL("https://mail.google.com/mail/");
		url.searchParams.set("view", "cm");
		url.searchParams.set("fs", "1");
		url.searchParams.set("to", COMPANY.email);
		url.searchParams.set("su", subject);
		url.searchParams.set("body", buildBody(data));
		window.open(url.toString(), "_blank", "noopener,noreferrer");
	}
	function sendMailto() {
		const href = `mailto:${COMPANY.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(buildBody(data))}`;
		window.location.href = href;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "ajanlat",
		className: "bg-bg-elevated px-5 py-24 md:px-8 md:py-32",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.22em] text-gold uppercase",
					children: "Ajánlatkérés"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display mt-4 text-4xl leading-[1.05] font-medium tracking-[-0.03em] text-fg md:text-5xl",
					children: ["Írja meg, mit szeretne.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block italic text-gold",
						children: "Mi visszaírunk."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-sm leading-relaxed text-muted",
					children: [
						"Töltse ki az űrlapot — a küldés előtt megmutatjuk a levél sablonját a cég logójával, majd Gmailen keresztül továbbítjuk a",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: COMPANY.email
						}),
						" címre. Adatbázis nincs: a levél az Ön Gmail-fiókjából megy ki."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: COMPANY.facebook,
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex min-h-12 items-center gap-3 rounded-2xl bg-surface px-4 text-sm text-fg shadow-card transition-[box-shadow] duration-150 hover:shadow-card-hover",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FacebookIcon, { className: "size-4 text-gold" }), "Kérjen ajánlatot Facebook-üzenetben"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: COMPANY.whatsapp,
							target: "_blank",
							rel: "noreferrer",
							className: "inline-flex min-h-12 items-center gap-3 rounded-2xl bg-surface px-4 text-sm text-fg shadow-card transition-[box-shadow] duration-150 hover:shadow-card-hover",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, { className: "size-4 text-gold" }),
								"WhatsApp: ",
								COMPANY.phoneDisplay
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `mailto:${COMPANY.email}`,
							className: "inline-flex min-h-12 items-center gap-3 rounded-2xl bg-surface px-4 text-sm text-fg shadow-card transition-[box-shadow] duration-150 hover:shadow-card-hover",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
								className: "size-4 text-gold",
								strokeWidth: 1.6
							}), COMPANY.email]
						})
					]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "rounded-[1.75rem] bg-surface p-5 shadow-card md:p-8",
				noValidate: true,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Név",
								htmlFor: "name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "name",
									className: "letter-input",
									autoComplete: "name",
									value: data.name,
									onChange: (e) => onChange("name", e.target.value),
									placeholder: "Teljes név"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Telefon",
								htmlFor: "phone",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "phone",
									className: "letter-input",
									autoComplete: "tel",
									inputMode: "tel",
									value: data.phone,
									onChange: (e) => onChange("phone", e.target.value),
									placeholder: "+36 …"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "E-mail",
								htmlFor: "email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "email",
									type: "email",
									className: "letter-input",
									autoComplete: "email",
									value: data.email,
									onChange: (e) => onChange("email", e.target.value),
									placeholder: "opcionális"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Helyszín",
								htmlFor: "location",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "location",
									className: "letter-input",
									value: data.location,
									onChange: (e) => onChange("location", e.target.value),
									placeholder: "Budapest, kerület / település"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Munka jellege",
									htmlFor: "service",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "service",
										className: "letter-input",
										value: data.service,
										onChange: (e) => onChange("service", e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Válasszon…"
											}),
											SERVICES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: s.title,
												children: s.title
											}, s.id)),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Egyéb",
												children: "Egyéb"
											})
										]
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:col-span-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Rövid leírás",
									htmlFor: "message",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: "message",
										className: "letter-input",
										value: data.message,
										onChange: (e) => onChange("message", e.target.value),
										placeholder: "Milyen munkáról van szó, mikorra tervezi, van-e terv?"
									})
								})
							})
						]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-gold-bright",
						role: "alert",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "submit",
						className: "mt-6 inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-full bg-gold px-6 text-sm font-medium text-bg transition-transform duration-150 ease-out hover:bg-gold-bright active:scale-[0.96]",
						children: ["Levél sablon megtekintése", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
							className: "size-4",
							strokeWidth: 1.7
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-xs leading-relaxed text-subtle",
						children: "A küldés a Gmail ablakában történik. Semmit nem tárolunk a weblapon."
					})
				]
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-[60] flex items-end justify-center bg-bg/70 p-3 backdrop-blur-sm sm:items-center",
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "letter-title",
			onClick: (e) => {
				if (e.target === e.currentTarget) setOpen(false);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-[1.75rem] bg-paper p-6 text-ink shadow-paper md:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							id: "letter-title",
							className: "sr-only",
							children: "Levél sablon"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "ml-auto flex size-11 items-center justify-center rounded-full text-ink-muted hover:text-ink",
							onClick: () => setOpen(false),
							"aria-label": "Bezárás",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/logo.png",
								alt: "Veress Gold Bau 369 logó",
								width: 96,
								height: 96,
								className: "size-24 rounded-full outline outline-1 -outline-offset-1 outline-ink/15"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display mt-4 text-2xl font-semibold tracking-tight text-ink",
								children: COMPANY.legalName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs tracking-[0.18em] text-gold-dim uppercase",
								children: COMPANY.tagline
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-5 h-px w-16 bg-gold/60" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-8 space-y-3 text-left text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "Név",
								v: data.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "Telefon",
								v: data.phone
							}),
							data.email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "E-mail",
								v: data.email
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "Munka",
								v: data.service
							}),
							data.location ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								k: "Helyszín",
								v: data.location
							}) : null
						]
					}),
					data.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 border-t border-ink/10 pt-5 text-left text-sm leading-relaxed text-ink-muted whitespace-pre-wrap",
						children: data.message
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-8 text-center text-[11px] tracking-wide text-ink-muted",
						children: [
							COMPANY.email,
							" · ",
							COMPANY.phoneDisplay
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid gap-2 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: sendGmail,
							className: "inline-flex min-h-12 items-center justify-center rounded-full bg-ink px-4 text-sm font-medium text-paper transition-transform duration-150 active:scale-[0.96]",
							children: "Küldés Gmailben"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: sendMailto,
							className: "inline-flex min-h-12 items-center justify-center rounded-full px-4 text-sm font-medium text-ink shadow-[inset_0_0_0_1px_rgba(26,23,20,0.18)] transition-transform duration-150 active:scale-[0.96]",
							children: "Megnyitás levelezőben"
						})]
					})
				]
			})
		}) : null]
	});
}
function Field({ label, htmlFor, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		htmlFor,
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs tracking-[0.14em] text-muted uppercase",
			children: label
		}), children]
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-[7rem_1fr] gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-ink-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-medium text-ink",
			children: v
		})]
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function BrandMark({ className, size = 44 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: "/logo.png",
		alt: "Veress Gold Bau 369",
		width: size,
		height: size,
		className: cn("rounded-full object-cover outline -outline-offset-1 outline-gold/30", className),
		style: {
			width: size,
			height: size
		}
	});
}
function RoofMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 88 44",
		fill: "none",
		"aria-hidden": "true",
		className: cn("text-gold", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M10 30 L32 12 L44 24 L60 10 L78 30",
				stroke: "currentColor",
				strokeWidth: "1.6",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 20 V11 H20 V16",
				stroke: "currentColor",
				strokeWidth: "1.6",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				fill: "currentColor",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "40.2",
						y: "26",
						width: "3.2",
						height: "3.2",
						rx: "0.3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "44.6",
						y: "26",
						width: "3.2",
						height: "3.2",
						rx: "0.3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "40.2",
						y: "30.4",
						width: "3.2",
						height: "3.2",
						rx: "0.3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "44.6",
						y: "30.4",
						width: "3.2",
						height: "3.2",
						rx: "0.3"
					})
				]
			})
		]
	});
}
function Services() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "szolgaltatasok",
		className: "relative bg-bg px-5 py-24 md:px-8 md:py-32",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.22em] text-gold uppercase",
					children: "Szolgáltatások"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-6 md:flex-row md:items-end md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display max-w-xl text-4xl leading-[1.05] font-medium tracking-[-0.03em] text-fg md:text-5xl",
						children: "Amit egy kézben tartunk."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-sm text-sm leading-relaxed text-muted",
						children: "Lakossági és céges megrendelőknek — bontástól a kulcsátadásig, Budapesten és Pest megyében."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-14 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: SERVICES.map((service, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "group rounded-3xl bg-surface p-6 shadow-card transition-[box-shadow,transform] duration-250 ease-[cubic-bezier(0.22,1,0.36,1)] hover:shadow-card-hover",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoofMark, { className: "h-8 w-16 opacity-80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-sm text-gold/70",
									children: String(i + 1).padStart(2, "0")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display mt-8 text-2xl font-medium tracking-tight text-fg",
								children: service.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								children: service.lead
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-subtle",
								children: service.body
							})
						]
					}, service.id))
				})
			]
		})
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		id: "kapcsolat",
		className: "border-t border-fg/10 bg-bg px-5 py-16 md:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 md:grid-cols-[1.2fr_1fr_1fr]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, { size: 48 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl font-semibold text-fg",
						children: COMPANY.shortName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-[0.16em] text-gold uppercase",
						children: "369 Kft."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-5 max-w-sm text-sm leading-relaxed text-muted",
					children: [
						COMPANY.tagline,
						" Bontás, felújítás, generálkivitelezés — ",
						COMPANY.area,
						"."
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.18em] text-subtle uppercase",
					children: "Elérhetőség"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `tel:${COMPANY.phoneTel}`,
							className: "inline-flex min-h-11 items-center gap-2 text-fg hover:text-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
								className: "size-4 text-gold",
								strokeWidth: 1.6
							}), COMPANY.phoneDisplay]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `mailto:${COMPANY.email}`,
							className: "inline-flex min-h-11 items-center gap-2 text-fg hover:text-gold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
								className: "size-4 text-gold",
								strokeWidth: 1.6
							}), COMPANY.email]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-2 text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
								className: "mt-0.5 size-4 text-gold",
								strokeWidth: 1.6
							}), COMPANY.area]
						})
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.18em] text-subtle uppercase",
					children: "Üzenet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: COMPANY.facebook,
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex min-h-11 items-center gap-2 text-sm text-fg hover:text-gold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FacebookIcon, { className: "size-4 text-gold" }), "Facebook oldal"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: COMPANY.whatsapp,
						target: "_blank",
						rel: "noreferrer",
						className: "inline-flex min-h-11 items-center gap-2 text-sm text-fg hover:text-gold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppIcon, { className: "size-4 text-gold" }), "WhatsApp"]
					})]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto mt-12 flex max-w-6xl flex-col gap-2 border-t border-fg/10 pt-6 text-xs text-subtle sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"© ",
				(/* @__PURE__ */ new Date()).getFullYear(),
				" ",
				COMPANY.legalName
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Generálkivitelezés · Házépítés · Lakásfelújítás · Budapest" })]
		})]
	});
}
var LINKS = [
	{
		href: "#szolgaltatasok",
		label: "Szolgáltatások"
	},
	{
		href: "#menet",
		label: "Menet"
	},
	{
		href: "#rolunk",
		label: "Rólunk"
	},
	{
		href: "#ajanlat",
		label: "Ajánlatkérés"
	}
];
function SiteHeader() {
	const [scrolled, setScrolled] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setScrolled(window.scrollY > 24);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "pointer-events-none fixed inset-x-0 top-0 z-50 px-3 pt-3 md:px-6 md:pt-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("pointer-events-auto mx-auto flex max-w-6xl items-center gap-3 rounded-full px-2 py-1.5 pl-2 pr-2 transition-[background,box-shadow,backdrop-filter] duration-250 ease-[cubic-bezier(0.22,1,0.36,1)] md:pr-1.5", scrolled || open ? "bg-bg-elevated/80 shadow-nav backdrop-blur-xl" : "bg-bg/25 backdrop-blur-md"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#top",
					className: "flex min-h-11 items-center gap-2.5 rounded-full py-0.5 pr-3 pl-0.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, { size: 40 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex flex-col leading-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-[17px] font-semibold tracking-tight text-fg",
							children: COMPANY.shortName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 text-[10px] tracking-[0.18em] text-gold uppercase",
							children: "369 Kft."
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "ml-auto hidden items-center gap-1 lg:flex",
					children: LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: link.href,
						className: "rounded-full px-3.5 py-2 text-sm text-muted transition-colors duration-150 hover:text-fg",
						children: link.label
					}, link.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: `tel:${COMPANY.phoneTel}`,
					className: "ml-auto hidden min-h-11 items-center gap-2 rounded-full px-3 text-sm text-fg/90 transition-colors duration-150 hover:text-gold md:ml-2 md:flex lg:ml-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {
						className: "size-3.5",
						strokeWidth: 1.75
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: COMPANY.phoneDisplay
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#ajanlat",
					className: "hidden min-h-11 items-center rounded-full bg-gold px-4 text-sm font-medium text-bg transition-transform duration-150 ease-out hover:bg-gold-bright active:scale-[0.96] md:inline-flex",
					children: "Ajánlatkérés"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "ml-auto flex size-11 items-center justify-center rounded-full text-fg md:ml-0 lg:hidden",
					"aria-expanded": open,
					"aria-controls": "mobile-nav",
					"aria-label": open ? "Menü bezárása" : "Menü megnyitása",
					onClick: () => setOpen((v) => !v),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			id: "mobile-nav",
			className: "pointer-events-auto mx-auto mt-2 max-w-6xl overflow-hidden rounded-3xl bg-bg-elevated/95 p-3 shadow-nav backdrop-blur-xl lg:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "flex flex-col",
				children: [
					LINKS.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: link.href,
						className: "flex min-h-12 items-center rounded-2xl px-4 text-base text-fg",
						onClick: () => setOpen(false),
						children: link.label
					}, link.href)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `tel:${COMPANY.phoneTel}`,
						className: "mt-1 flex min-h-12 items-center gap-2 rounded-2xl px-4 text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), COMPANY.phoneDisplay]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "#ajanlat",
						onClick: () => setOpen(false),
						className: "mt-2 flex min-h-12 items-center justify-center rounded-2xl bg-gold text-sm font-medium text-bg",
						children: "Ajánlatkérés"
					})
				]
			})
		}) : null]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Services, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Process, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteForm, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Home as component };
